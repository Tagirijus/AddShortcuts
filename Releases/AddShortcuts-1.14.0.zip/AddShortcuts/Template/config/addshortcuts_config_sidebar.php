<li <?= $this->app->checkMenuSelection('AddShortcutsController', 'show') ?>>
    <a href="/addshortcuts/config"><?= t('AddShortcuts configuration') ?></a>
</li>
