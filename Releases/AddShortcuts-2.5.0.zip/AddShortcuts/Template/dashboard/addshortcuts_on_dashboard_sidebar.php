<li <?= $this->app->checkMenuSelection('AddShortcutsController', 'viewShortcutPresetSelectModal') ?>>
    <a href="/addshortcuts/shortcutPresetSelectModal" class="js-modal-small">Shortcuts</a>
</li>
