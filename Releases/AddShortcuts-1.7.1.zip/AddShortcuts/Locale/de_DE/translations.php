<?php

return array(
    'Switch to the tasks view' => 'Zur Task-Ansicht',
    'Open Big Board' => 'Öffne das Big Board',
    'Various' => 'Sonstiges',
    'Home' => 'Startseite',
    'Add spent time' => 'Füge getätigte Zeit hinzu',
    'AddShortcuts configuration' => 'AddShortcuts Einstellungen',
    'v + NUMBER shortcuts' => 'v + ZAHL Shortcuts',
    'You have 10 possible links to fill, which will get activated when pressing the letter v and a number between 0 and 9.' => 'Es gibt 10 mögliche Links, die man eintragen kann, sodass man den Buchstaben v und eine Zahl zwischen 0 und 9 drücken kann, um diesen Link zu aktivieren.',
    'Switch to the url set up for this number in the config' => 'Zur URL, die in der Config eingestellt wurde für die Zahl'
);
